// postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},   // обычный плагин для Tailwind v3
    autoprefixer: {},
  },
};
