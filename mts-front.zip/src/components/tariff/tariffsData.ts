// Оставить только корректный экспорт:
export const tariffsData = [
  // Полные данные тарифов
  {
    id: 1,
    name: "МТС Домашний интернет 300",
    type: "Интернет",
    speed: 300,
    technology: "GPON",
    price: 750,
    iconInternet: "/icons/ethernet.svg",
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 2,
    name: "МТС Домашний интернет 100",
    type: "Интернет",
    speed: 100,
    technology: "FTTB",
    price: 650,
    iconInternet: "/icons/ethernet.svg",
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru",
      "Оборудование и услуга «Гарантия+» бесплатно 1 месяц"
    ],
    buttonColor: "purple"
  },
  {
    id: 3,
    name: "Технологии развлечения Макси 300",
    type: "Интернет + ТВ",
    speed: 300,
    technology: "GPON",
    tvChannels: 210,
    price: 850,
    iconInternet: "/icons/ethernet.svg",
    iconTV: "/icons/tv.svg",
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 4,
    name: "Технологии развлечения Тест-драйв",
    type: "Интернет + ТВ",
    speed: 100,
    technology: "FTTB",
    tvChannels: 210,
    price: 750,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru",
      "Оборудование и услуга «Гарантия+» бесплатно 1 месяц"
    ],
    buttonColor: "purple"
  },
  {
    id: 5,
    name: "Технологии выгоды Тест-драйв",
    type: "Интернет + ТВ + Моб. связь",
    speed: 250,
    technology: "GPON",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 1000,
    price: 950,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Перенос остатков минут и ГБ"
    ],
    isHit: true,
    buttonColor: "purple"
  },
  {
    id: 6,
    name: "МТС Домашний интернет 100",
    type: "Интернет",
    speed: 200,
    technology: "GPON",
    price: 650,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru",
      "Оборудование и услуга «Гарантия+» бесплатно 1 месяц"
    ],
    isHit: true,
    buttonColor: "purple"
  },
  {
    id: 7,
    name: "Технологии развлечения Тест-драйв",
    type: "Интернет + ТВ",
    speed: 200,
    technology: "GPON",
    tvChannels: 210,
    price: 750,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru",
      "Оборудование и услуга «Гарантия+» бесплатно 1 месяц"
    ],
    isHit: true,
    buttonColor: "purple"
  },
  {
    id: 8,
    name: "Технологии общения Тест-драйв",
    type: "Интернет + Моб. связь",
    speed: 250,
    technology: "GPON",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 750,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    isHit: true,
    buttonColor: "purple"
  },
  {
    id: 9,
    name: "Технологии общения Семейный",
    type: "Интернет + Моб. связь",
    speed: 500,
    technology: "GPON",
    mobileData: 40,
    mobileMinutes: 2000,
    price: 950,
    discountPrice: 475,
    discountPeriod: "первые 2 месяца",
    discountPercentage: 50,
    features: [
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 10,
    name: "Технологии общения Тест-драйв",
    type: "Интернет + Моб. связь",
    speed: 100,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 750,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 11,
    name: "Технологии развлечения Макси 500",
    type: "Интернет + ТВ",
    speed: 500,
    technology: "GPON",
    tvChannels: 210,
    price: 950,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 12,
    name: "Игровой",
    type: "Интернет + ТВ",
    speed: 650,
    technology: "GPON",
    tvChannels: 210,
    price: 1150,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 13,
    name: "Технологии доступа Макси 500",
    type: "Интернет",
    speed: 500,
    technology: "GPON",
    price: 900,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 14,
    name: "Технологии выгоды Тест-драйв",
    type: "Интернет + ТВ + Моб. связь",
    speed: 100,
    technology: "FTTB",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 1000,
    price: 950,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 15,
    name: "Игровой",
    type: "Интернет",
    speed: 650,
    technology: "GPON",
    price: 950,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры",
      "Wi-Fi роутер — 120 ₽/мес в аренду"
    ],
    buttonColor: "orange"
  },
  {
    id: 16,
    name: "Технологии развлечения Макси 300",
    type: "Интернет + ТВ",
    speed: 300,
    technology: "FTTB",
    tvChannels: 210,
    price: 850,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 17,
    name: "Технологии общения Тест-драйв",
    type: "Интернет + Моб. связь",
    speed: 250,
    technology: "GPON",
    mobileData: 40,
    mobileMinutes: 2000,
    price: 950,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 18,
    name: "Технологии выгоды Семейный",
    type: "Интернет + ТВ + Моб. связь",
    speed: 500,
    technology: "GPON",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 2000,
    price: 1200,
    discountPrice: 600,
    discountPeriod: "первые 2 месяца",
    discountPercentage: 50,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 19,
    name: "Технологии развлечения Макси 500",
    type: "Интернет + ТВ",
    speed: 500,
    technology: "FTTB",
    tvChannels: 210,
    price: 950,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 20,
    name: "Технологии выгоды Тест-драйв",
    type: "Интернет + ТВ + Моб. связь",
    speed: 250,
    technology: "GPON",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 2000,
    price: 1200,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 21,
    name: "Технологии доступа Макси 500",
    type: "Интернет",
    speed: 500,
    technology: "FTTB",
    price: 900,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "+10 ГБ облачного хранилища от Mail.ru"
    ],
    buttonColor: "orange"
  },
  {
    id: 22,
    name: "Технологии общения Тест-драйв",
    type: "Интернет + Моб. связь",
    speed: 100,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 750,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 23,
    name: "Технологии выгоды Тест-драйв",
    type: "Интернет + ТВ + Моб. связь",
    speed: 100,
    technology: "FTTB",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 1000,
    price: 950,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 24,
    name: "Игровой",
    type: "Интернет + ТВ",
    speed: 500,
    technology: "FTTB",
    tvChannels: 210,
    price: 1150,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 25,
    name: "Игровой",
    type: "Интернет",
    speed: 500,
    technology: "FTTB",
    price: 950,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 26,
    name: "Игровой 4в1",
    type: "Интернет + ТВ + Моб. связь",
    speed: 650,
    technology: "GPON",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1400,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 27,
    name: "Игровой 2в1",
    type: "Интернет + Моб. связь",
    speed: 650,
    technology: "GPON",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1200,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 28,
    name: "Технологии общения Семейный",
    type: "Интернет + Моб. связь",
    speed: 100,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 2000,
    price: 950,
    discountPrice: 475,
    discountPeriod: "первые 2 месяца",
    discountPercentage: 50,
    features: [
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 29,
    name: "Технологии общения Тест-драйв",
    type: "Интернет + Моб. связь",
    speed: 100,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 2000,
    price: 950,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 30,
    name: "Технологии выгоды Семейный",
    type: "Интернет + ТВ + Моб. связь",
    speed: 100,
    technology: "FTTB",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 2000,
    price: 1200,
    discountPrice: 600,
    discountPeriod: "первые 2 месяца",
    discountPercentage: 50,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 31,
    name: "Технологии выгоды+ Тест-драйв",
    type: "Интернет + ТВ + Моб. связь",
    speed: 100,
    technology: "FTTB",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 2000,
    price: 1200,
    discountPrice: 0,
    discountPeriod: "первый месяц",
    discountPercentage: 100,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "purple"
  },
  {
    id: 32,
    name: "Технологии общения+",
    type: "Интернет + Моб. связь",
    speed: 100,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 950,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam"
    ],
    buttonColor: "orange"
  },
  {
    id: 33,
    name: "Игровой 4в1+",
    type: "Интернет + ТВ + Моб. связь",
    speed: 650,
    technology: "GPON",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 2000,
    price: 1600,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 34,
    name: "Игровой 2в1+",
    type: "Интернет + Моб. связь",
    speed: 650,
    technology: "GPON",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1400,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 35,
    name: "Игровой 4в1",
    type: "Интернет + ТВ + Моб. связь",
    speed: 500,
    technology: "FTTB",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1400,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 36,
    name: "Игровой 2в1+",
    type: "Интернет + Моб. связь",
    speed: 650,
    technology: "GPON",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1400,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 120 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 37,
    name: "Игровой 2в1",
    type: "Интернет + Моб. связь",
    speed: 500,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1200,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 38,
    name: "Игровой 4в1+",
    type: "Интернет + ТВ + Моб. связь",
    speed: 500,
    technology: "FTTB",
    tvChannels: 210,
    mobileData: 40,
    mobileMinutes: 2000,
    price: 1600,
    features: [
      "KION (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  },
  {
    id: 39,
    name: "Игровой 2в1+",
    type: "Интернет + Моб. связь",
    speed: 500,
    technology: "FTTB",
    mobileData: 40,
    mobileMinutes: 1000,
    price: 1400,
    features: [
      "KION на 180 дней (20 000 фильмов и сериалов)",
      "Перенос остатков минут и ГБ",
      "Wi-Fi роутер — 80 ₽/мес в аренду",
      "Бесплатный доступ к Одноклассники и ВКонтакте",
      "Бесплатный доступ к мессенджерам WhatsApp, Telegram, TamTam",
      "Бонусы в играх от 4GAME",
      "Бонусы в играх от VK Play",
      "Бонусы в играх от Леста Игры"
    ],
    buttonColor: "orange"
  }
]; 